package fck2068.e.plantatree;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ListViewAdapter extends BaseAdapter {

    //variables
    Context mContext;
    LayoutInflater inflater;
    List<Tree> treeList;
    ArrayList<Tree> arrayList;

    //constructor
    public ListViewAdapter(Context context, List<Tree> modelList) {
        mContext = context;
        this.treeList = modelList;
        inflater = LayoutInflater.from(mContext);
        this.arrayList = new ArrayList<Tree>();
        this.arrayList.addAll(treeList);
    }

    public class ViewHolder{
        TextView mTitleTV, mPriceTV;
        ImageView mIconIV;
    }

    @Override
    public int getCount() {
        return treeList.size();
    }

    @Override
    public Object getItem(int position) {
        return treeList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView==null){
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.row, null);

            //locate the views in row.xml
            holder.mTitleTV = convertView.findViewById(R.id.mainTitle);
            holder.mPriceTV = convertView.findViewById(R.id.mainPrice);
            holder.mIconIV = convertView.findViewById(R.id.mainImage);

            convertView.setTag(holder);
        }else {
            holder = (ViewHolder)convertView.getTag();
        }
        //set the results into textview
        holder.mTitleTV.setText(treeList.get(position).getTitle());
        holder.mPriceTV.setText(treeList.get(position).getPrice());
        //set the result in imageview
        holder.mIconIV.setImageResource(treeList.get(position).getIcon());

        //listview item clicks
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(treeList.get(position).getTitle().trim().equals("Pine tree")){
                    //start newActivity with title for actionbar and text for textview
                    Intent intent = new Intent(mContext, TreeViewActivity.class);
                    intent.putExtra("actionBarTitle", "Pine");;

                    intent.putExtra("contentTV", "Description for Pine tree..");
                    mContext.startActivity(intent);
                }
                if(treeList.get(position).getTitle().trim().equals("Apple tree")){
                    //start newActivity with title for actionbar and text for textview
                    Intent intent = new Intent(mContext, TreeViewActivity.class);
                    intent.putExtra("actionBarTitle", "Apple");;

                    intent.putExtra("contentTV", "Description for Apple tree..");
                    mContext.startActivity(intent);
                }
                if(treeList.get(position).getTitle().trim().equals("Maple tree")){
                    //start newActivity with title for actionbar and text for textview
                    Intent intent = new Intent(mContext, TreeViewActivity.class);
                    intent.putExtra("actionBarTitle", "Maple");;

                    intent.putExtra("contentTV", "Description for Maple tree..");
                    mContext.startActivity(intent);
                }
                if(treeList.get(position).getTitle().trim().equals("Oak tree")){
                    //start newActivity with title for actionbar and text for textview
                    Intent intent = new Intent(mContext, TreeViewActivity.class);
                    intent.putExtra("actionBarTitle", "Oak");;

                    intent.putExtra("contentTV", "Description for Oak tree..");
                    mContext.startActivity(intent);
                }
            }
        });

        return convertView;
    }

    //filter
    public void filter(String charText){
        charText = charText.toLowerCase(Locale.getDefault());
        treeList.clear();
        if(charText.length()==0){
            treeList.addAll(arrayList);
        } else {
            for(Tree model: arrayList){
                if(model.getTitle().toLowerCase(Locale.getDefault()).contains(charText)){
                    treeList.add(model);
                }
            }
        }
        notifyDataSetChanged();
    }
}
